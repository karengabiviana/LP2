﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();
        }

        private void btnAdicao_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out numero1))
            {
                MessageBox.Show("O Número 1 precisa ser válido");
                txtNumero1.Clear();
                txtNumero1.Focus();
            }
            else
            {
                if (!Double.TryParse(txtNumero2.Text, out numero2))
                {
                    MessageBox.Show("O Número 2 precisa ser válido");
                    txtNumero2.Clear();
                    txtNumero2.Focus();
                }
                else
                {
                    Double resultado = numero1 + numero2;
                    txtResultado.Text = resultado.ToString();
                }
            }
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out numero1))
            {
                MessageBox.Show("O Número 1 precisa ser válido");
                txtNumero1.Clear();
                txtNumero1.Focus();
            }
            else
            {
                if (!Double.TryParse(txtNumero2.Text, out numero2))
                {
                    MessageBox.Show("O Número 2 precisa ser válido");
                    txtNumero2.Clear();
                    txtNumero1.Focus();
                }
                else
                {
                    Double resultado = numero1 - numero2;
                    txtResultado.Text = resultado.ToString();
                }
            }
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out numero1))
            {
                MessageBox.Show("O Número 1 precisa ser válido");
                txtNumero1.Clear();
                txtNumero1.Focus();
            }
            else
            {
                if (!Double.TryParse(txtNumero2.Text, out numero2))
                {
                    MessageBox.Show("O Número 2 precisa ser válido");
                    txtNumero2.Clear();
                    txtNumero1.Focus();
                }
                else
                {
                    Double resultado = numero1 * numero2;
                    txtResultado.Text = resultado.ToString();
                }
            }
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out numero1))
            {
                MessageBox.Show("O Número 1 precisa ser válido");
                txtNumero1.Clear();
                txtNumero1.Focus();
            }
            else
            {
                if (!Double.TryParse(txtNumero2.Text, out numero2))
                {
                    MessageBox.Show("O Número 2 precisa ser válido");
                    txtNumero2.Clear(); 
                    txtNumero1.Focus();
                }
                else
                {
                    if (numero2 == 0)
                    {
                        MessageBox.Show("Não é possível o divisor ser Zero!");
                        txtNumero2.Focus();
                        txtNumero2.Clear();
                    }
                    else
                    {
                        Double resultado = numero1 / numero2;
                        txtResultado.Text = resultado.ToString();
                    }
                }
            }
        }
    }
}
