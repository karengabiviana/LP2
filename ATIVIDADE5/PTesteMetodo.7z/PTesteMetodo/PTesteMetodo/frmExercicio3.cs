﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodo
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            txtPalavra2.Text = txtPalavra2.Text.Replace(txtPalavra1.Text, "");
        }

        private void btnDeTrásPraFrente_Click(object sender, EventArgs e)
        {
            string ajudante = txtPalavra1.Text;
            char[] arr = ajudante.ToCharArray();
            Array.Reverse(arr);

            ajudante = new string(arr);

            txtPalavra2.Text = ajudante;
        }
    }
}
