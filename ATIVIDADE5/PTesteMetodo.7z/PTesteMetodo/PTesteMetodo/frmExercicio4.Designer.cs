﻿namespace PTesteMetodo
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnCaracterAlfabetico = new System.Windows.Forms.Button();
            this.btnEspacoEmBranco = new System.Windows.Forms.Button();
            this.btnCaractesNumericos = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(205, 93);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(361, 96);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btnCaracterAlfabetico
            // 
            this.btnCaracterAlfabetico.Location = new System.Drawing.Point(508, 279);
            this.btnCaracterAlfabetico.Name = "btnCaracterAlfabetico";
            this.btnCaracterAlfabetico.Size = new System.Drawing.Size(158, 66);
            this.btnCaracterAlfabetico.TabIndex = 9;
            this.btnCaracterAlfabetico.Text = "Caracteres Alfabéticos";
            this.btnCaracterAlfabetico.UseVisualStyleBackColor = true;
            this.btnCaracterAlfabetico.Click += new System.EventHandler(this.btnInserirAsteriscos_Click);
            // 
            // btnEspacoEmBranco
            // 
            this.btnEspacoEmBranco.Location = new System.Drawing.Point(320, 279);
            this.btnEspacoEmBranco.Name = "btnEspacoEmBranco";
            this.btnEspacoEmBranco.Size = new System.Drawing.Size(127, 66);
            this.btnEspacoEmBranco.TabIndex = 8;
            this.btnEspacoEmBranco.Text = "Local do 1º caracter branco";
            this.btnEspacoEmBranco.UseVisualStyleBackColor = true;
            this.btnEspacoEmBranco.Click += new System.EventHandler(this.btnTexto1noTexto2_Click);
            // 
            // btnCaractesNumericos
            // 
            this.btnCaractesNumericos.Location = new System.Drawing.Point(166, 279);
            this.btnCaractesNumericos.Name = "btnCaractesNumericos";
            this.btnCaractesNumericos.Size = new System.Drawing.Size(116, 66);
            this.btnCaractesNumericos.TabIndex = 7;
            this.btnCaractesNumericos.Text = "Caracteres Numéricos";
            this.btnCaractesNumericos.UseVisualStyleBackColor = true;
            this.btnCaractesNumericos.Click += new System.EventHandler(this.btnTestarIguais_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCaracterAlfabetico);
            this.Controls.Add(this.btnEspacoEmBranco);
            this.Controls.Add(this.btnCaractesNumericos);
            this.Controls.Add(this.rchtxtFrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnCaracterAlfabetico;
        private System.Windows.Forms.Button btnEspacoEmBranco;
        private System.Windows.Forms.Button btnCaractesNumericos;
    }
}