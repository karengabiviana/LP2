﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodo
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnTestarIguais_Click(object sender, EventArgs e)
        {
            if (String.Compare(txtPalavra1.Text, txtPalavra2.Text, true) == 0)
            {
                MessageBox.Show("São iguais");
            }
            else
            {
                MessageBox.Show("Não são iguais");
            }
        }  


        private void txtPalavra1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnTexto1noTexto2_Click(object sender, EventArgs e)
        {
            int metadeString = txtPalavra2.Text.Length /2 ;

            string novaString = txtPalavra2.Text.Substring(0, metadeString) + txtPalavra1.Text + txtPalavra2.Text.Substring(metadeString);

            txtPalavra2.Text = novaString;
        }

        private void btnInserirAsteriscos_Click(object sender, EventArgs e)
        {
            int metadeString = txtPalavra1.Text.Length / 2;

            string novaString = txtPalavra1.Text.Insert(metadeString, "**");

            txtPalavra2.Text = novaString;
        }
    }
}
