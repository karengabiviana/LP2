﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodo
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnTestarIguais_Click(object sender, EventArgs e)
        {
            int contador = 0;
            int contNum = 0;
            while (contador < rchtxtFrase.Text.Length)
            {
                if (char.IsNumber(rchtxtFrase.Text[contador-1]))
                {
                    contNum++;
                }
               
                contador++;
            }
            MessageBox.Show("Número de caracteres numéricos é "+ contNum);
        }

        private void btnInserirAsteriscos_Click(object sender, EventArgs e)
        {
            int contador = 0;

            foreach (char caracter in rchtxtFrase.Text)
            {
                if (char.IsLetter(caracter))
                {
                    contador ++;
                }
            }
            MessageBox.Show("Número de caracteres Alfabéticos é " + contador);
        }

        private void btnTexto1noTexto2_Click(object sender, EventArgs e)
        {
            int posicao = 0;

            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    posicao = i + 1;
                    break;
                }
            }
            
            MessageBox.Show("A posição do primeiro espaço em branco é "+ posicao);
        }
    }
}
