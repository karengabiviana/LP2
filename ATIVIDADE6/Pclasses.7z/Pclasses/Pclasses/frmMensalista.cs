﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }

        private void btnInstanciar_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista();

            objMensalista.NomeEmpregado = txtNome.Text;
            objMensalista.Matricula =
                Convert.ToInt32(txtMatricula.Text);
            objMensalista.DataEntradaEmpresa =
                Convert.ToDateTime(txtDataEntrada.Text);
            objMensalista.SalarioMensal =
                Convert.ToDouble(txtSalMensal.Text);

            MessageBox.Show("Nome= " + objMensalista.NomeEmpregado + "\n" +
                "Matricula=" + objMensalista.Matricula + "\n" +
                "Tempo Trabalho: " +
                objMensalista.TempoTrabalho() + "\n" + "Salario Final =" +
                objMensalista.SalarioBruto().ToString("N2"));

            MessageBox.Show(Mensalista.empresa);
        }

        private void btnPassarParametro_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista(
                Convert.ToInt32(txtMatricula.Text),
                txtNome.Text,
                Convert.ToDateTime(txtDataEntrada.Text),
                Convert.ToDouble(txtSalMensal.Text));

            MessageBox.Show("Nome= " + objMensalista.NomeEmpregado + "\n" +
                "Matricula=" + objMensalista.Matricula + "\n" +
                "Tempo Trabalho: " +
                objMensalista.TempoTrabalho() + "\n" + "Salario Final =" +
                objMensalista.SalarioBruto().ToString("N2"));
        }
    }
}
