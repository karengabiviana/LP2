﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;

        public Form1()
        {
            InitializeComponent();
        }

        private void mskbxPesoAtual_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
           
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                peso = Convert.ToDouble(mskbxPesoAtual.Text);
                
            }
            catch
            {
                MessageBox.Show("Insira um valor de Peso válido!");
                mskbxPesoAtual.Focus();
            }
            
            try
            {
                altura = Convert.ToDouble(mskbxAltura.Text);
                
            }
            catch
            {
                MessageBox.Show("Insira um valor de Altura válido!");
                mskbxPesoAtual.Focus();
            }
            
            imc = peso / Math.Pow(altura, 2);
            imc = Math.Round(imc, 1);
            mskbxIMC.Text = imc.ToString();

            if (imc < 18.5)
            {
                MessageBox.Show("MAGREZA");
            }
            else
            {
                if (imc <= 24.9)
                {
                    MessageBox.Show("NORMAL");
                }
                else
                {
                    if (imc <= 29.9)
                    {
                        MessageBox.Show("SOBREPESO");
                    }
                    else
                    {
                        if (imc <= 39.9)
                        {
                            MessageBox.Show("OBESIDADE");
                        }
                        else
                        {
                            MessageBox.Show("OBESIDADE GRAVE");
                        }
                        
                    }
                }
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxPesoAtual.Clear();
            mskbxAltura.Clear();
            mskbxIMC.Clear();
        }
    }
}
