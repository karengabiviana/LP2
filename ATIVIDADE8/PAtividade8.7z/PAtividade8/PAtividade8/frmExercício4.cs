﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade8
{
    public partial class frmExercício4 : Form
    {
        public frmExercício4()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string auxiliar = "";
            string[] nomes = new string[10];
            int[] tamanhoNomes = new int[10];
            string resposta = "";

            for (int i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox("Digite o nome completo",
                    "Entrada de dados");
                if (auxiliar == "")
                    break;

                if (auxiliar.Replace(" ", "").Length == 0)
                {
                    MessageBox.Show("Entrada inválida!");
                    i--;
                }
                else
                {
                    auxiliar.Replace(" ", "");
                    nomes[i] = auxiliar;
                    tamanhoNomes[i] = nomes[i].Length;
                    resposta = $"O nome {nomes[i]} tem {tamanhoNomes[i]} caracteres";
                    lstbxNomes.Items.Add(resposta);
                }

            }  
        }
    }
}
