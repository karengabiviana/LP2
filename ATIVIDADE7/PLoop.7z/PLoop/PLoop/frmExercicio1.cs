﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoop
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspacoBranco_Click(object sender, EventArgs e)
        {
            int numEspaco = 0;
            int tamanhoFrase = rchTxtTexto.Text.Length;

            if (rchTxtTexto.Text == "")
            {
                MessageBox.Show("Digite uma frase!");
            }
            else
            {
                for (int i = 0; i < tamanhoFrase; i++)
                {
                    if (Char.IsWhiteSpace(rchTxtTexto.Text[i]))
                    {
                        numEspaco++;
                    }
                }
                MessageBox.Show("O número de espaços em branco é: " + numEspaco);
            }
        }

        private void btnApareceR_Click(object sender, EventArgs e)
        {
            int qtdeR = 0;
            if (rchTxtTexto.Text == "")
            {
                MessageBox.Show("Digite algo!");
            }
            else
            {
                foreach (char c in rchTxtTexto.Text.ToUpper())
                {
                    if (c == 'R')
                        qtdeR++;
                }
                MessageBox.Show("O numero de letras 'R' é: " + qtdeR);
            }
        }

        private void btnParLetrasRepetidas_Click(object sender, EventArgs e)
        {
            int pares = 0;
            int i = 0;

            if (rchTxtTexto.Text == "")
            {
                MessageBox.Show("Digite alguma coisa!");
            }
            else
            {
                while (i < rchTxtTexto.Text.Length - 1)
                {
                    if (rchTxtTexto.Text[i] == rchTxtTexto.Text[i + 1])
                    {
                        pares++;
                    }
                    i++;
                }
                MessageBox.Show("O número de vezes que ocorre mesmo par de letras é " + pares);
            }
        }
    }
}
