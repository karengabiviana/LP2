﻿namespace PLoop
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchTxtTexto = new System.Windows.Forms.RichTextBox();
            this.btnEspacoBranco = new System.Windows.Forms.Button();
            this.btnApareceR = new System.Windows.Forms.Button();
            this.btnParLetrasRepetidas = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchTxtTexto
            // 
            this.rchTxtTexto.Location = new System.Drawing.Point(208, 107);
            this.rchTxtTexto.Name = "rchTxtTexto";
            this.rchTxtTexto.Size = new System.Drawing.Size(369, 96);
            this.rchTxtTexto.TabIndex = 0;
            this.rchTxtTexto.Text = "";
            // 
            // btnEspacoBranco
            // 
            this.btnEspacoBranco.Location = new System.Drawing.Point(69, 290);
            this.btnEspacoBranco.Name = "btnEspacoBranco";
            this.btnEspacoBranco.Size = new System.Drawing.Size(205, 68);
            this.btnEspacoBranco.TabIndex = 1;
            this.btnEspacoBranco.Text = "Nº de espaços em branco na frase";
            this.btnEspacoBranco.UseVisualStyleBackColor = true;
            this.btnEspacoBranco.Click += new System.EventHandler(this.btnEspacoBranco_Click);
            // 
            // btnApareceR
            // 
            this.btnApareceR.Location = new System.Drawing.Point(316, 290);
            this.btnApareceR.Name = "btnApareceR";
            this.btnApareceR.Size = new System.Drawing.Size(205, 68);
            this.btnApareceR.TabIndex = 2;
            this.btnApareceR.Text = "Nº de vezes em que aparece \"R\"";
            this.btnApareceR.UseVisualStyleBackColor = true;
            this.btnApareceR.Click += new System.EventHandler(this.btnApareceR_Click);
            // 
            // btnParLetrasRepetidas
            // 
            this.btnParLetrasRepetidas.Location = new System.Drawing.Point(563, 290);
            this.btnParLetrasRepetidas.Name = "btnParLetrasRepetidas";
            this.btnParLetrasRepetidas.Size = new System.Drawing.Size(205, 68);
            this.btnParLetrasRepetidas.TabIndex = 3;
            this.btnParLetrasRepetidas.Text = "Nº de vezes que ocorre o mesmo par de letras";
            this.btnParLetrasRepetidas.UseVisualStyleBackColor = true;
            this.btnParLetrasRepetidas.Click += new System.EventHandler(this.btnParLetrasRepetidas_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnParLetrasRepetidas);
            this.Controls.Add(this.btnApareceR);
            this.Controls.Add(this.btnEspacoBranco);
            this.Controls.Add(this.rchTxtTexto);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchTxtTexto;
        private System.Windows.Forms.Button btnEspacoBranco;
        private System.Windows.Forms.Button btnApareceR;
        private System.Windows.Forms.Button btnParLetrasRepetidas;
    }
}