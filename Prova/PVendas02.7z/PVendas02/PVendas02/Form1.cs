﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string auxiliar = "";
            double[,] mesEsemana = new double[2,4];
            double totalMes = 0;
            double totalGeral = 0;
           
            for (int i = 0; i < 2; i++)
            {

                for (int j = 0; j < 4; j++)
                {
                    auxiliar = Interaction.InputBox("Insira total de vendas",
                    "Entrada de dados");
                    if (auxiliar == "")
                        break;

                    if (!double.TryParse(auxiliar, out mesEsemana[i, j]))
                    {
                        MessageBox.Show("Entrada inválida!");
                        i--;
                    }
                    else
                    {
                        totalMes += mesEsemana[i, j];

                        lstbxResultado.Items.Add($"Total do mês: {(i + 1)} Semana: {j + 1} {mesEsemana[i, j].ToString("C2")}");
                    }
                    
                }
                lstbxResultado.Items.Add($" >> Total Mês: {totalMes.ToString("C2")}");
                
                lstbxResultado.Items.Add("----------------------------------");
                totalGeral += totalMes;
                totalMes = 0;

            }
            lstbxResultado.Items.Add($" >> Total Geral: {totalGeral.ToString("C2")}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxResultado.Items.Clear();
        }
    }
}
